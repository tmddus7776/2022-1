#include<iostream>
using namespace std;

int main() {
	int hour, minute;
	cout << "Put the hour value: ";
	cin >> hour;
	
	cout << "Put the minute value: ";
	cin >> minute;
	
	cout << "The time is " << hour << ":" << minute;
	return 0;
}
