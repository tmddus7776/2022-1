#include<iostream>
using namespace std;

int main() {
	double km = 0.1846;
	double mile = km * 0.621371;
	
	cout << "The distance is " << mile << " miles";
}
